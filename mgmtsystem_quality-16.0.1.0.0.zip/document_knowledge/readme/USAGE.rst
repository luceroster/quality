This module adds a new top level menu *Knowledge*

Users with permission *Central access to Documents* can access in
*Knowledge/Documents* to all the documents attached to records of any model
for which they have read permission.
