Users must be added to the appropriate groups within Odoo as follows:

* Creators: Settings > Users > Groups > Management System / User

To configure email notifications for certain stages go to:

* Management System > Configuration > Nonconformities > Stages
* Click on any stage and click the edit button.
* Click on the dropdown icon in the field Email Template, select your template and click Save.
