# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import copy_verification_lines
