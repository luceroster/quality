# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import test_document_page
from . import test_document_page_create_menu
from . import test_document_page_history
from . import test_document_page_show_diff
