* Savoir-faire Linux <support@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Eugen Don <eugen.don@don-systems.de>
* Jose Maria Alzaga <jose.alzaga@aselcis.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda

Trobz

* Dung Tran <dungtd@trobz.com>
* Yvan Dotet <yvan.dotet@logicasoft.eu>
