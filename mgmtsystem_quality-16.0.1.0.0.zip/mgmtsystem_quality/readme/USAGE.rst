To use this module, you need to:

* Schedule iand manage your audit calendars and top management reviews
* Follow up with your colleagues on their actions
* Analyze your NC and determine your action plan
* Evaluate the effectiveness of your action plan before closing NC
* Maintain your documentation by approving or refusing changes
* Create improvement opportunities
